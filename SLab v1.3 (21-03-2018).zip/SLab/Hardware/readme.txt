=======================================================
 SLab System v1.3 (1/03/2018)
=======================================================
 Hardware Folder Contents
=======================================================

This folder contains the hardware design for the F303RE Shield "A" as a KiCad project file

