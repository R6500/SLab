=======================================================
 SLab System v1.2 (11/2/2018)
=======================================================
 Firmware Folder Contents
=======================================================

This folder contains the firmware of the supported hardware boards

It contains the following text files:

   readme.txt : The file you are reading
  license.txt : Slab Firmware license information

It contains the following subfolders:

Bin : Binary firmware for the boards
      It the case of the Nucleo boards it is drag and drop

        SLAB-Nucleo64-F303RE-1.2 (2018-02-11)
        Firmware for the STM32 Nucleo64 F303RE Board
        This is the best available SLab firmware

        SLAB-Nucleo64-L152RE-1.2 (2018-02-11)
        Firmware for the STM32 Nucleo64 L152RE Board
        This is firmware is more limited in sampling times than the 303RE one

Source : Source code for the firmware 

