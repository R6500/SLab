'''
SLab Calibration Stage 4
calibrate4.py

Check calibration
'''

import slab

slab.connect()

slab.checkCalibration()

slab.disconnect()




    
