=======================================================
 SLab System v1.2 (11/02/2017)
=======================================================
 Hardware Folder Contents
=======================================================

This folder contains the hardware design for the F303RE Shield "A" as a KiCad project file

